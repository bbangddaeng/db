package javadb;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;



public class Panels extends JPanel{
	String[] Columns = {};
	//String[][] Col = {{}};
	String str;
	String[] chkBoxName = {"NAME","SSN","BIRTHDATE","ADDRESS",
							"SEX","SALARY","SUPERVISOR","DEPARTMENT"};
	int[] checkValues = new int[8];
	JPanel panel = new JPanel();
	static int rowSize = 0;

	static int num=0;
	static String[] tableName = new String[9];
	static String[][] Col = new String[20][11];
	

}


class NorthPanel extends Panels {
	public NorthPanel() {
		setBackground(Color.BLACK);
		setLayout(new FlowLayout());
		JLabel teamName = new JLabel("DB 8주차 4조");
		teamName.setForeground(Color.WHITE);
		add(teamName);
	}
}

class OptionPanel extends Panels {
	JPanel tableSelectPanel = new JPanel();
	JPanel columnSelectPanel = new JPanel();
	JPanel rightPanel = new JPanel();
	JPanel tablePanel = new JPanel();
//	int tableNumber = 0;
	JCheckBox[] checkBoxes = new JCheckBox[8];
	CompanyDBController cont = new CompanyDBController("!","@","#");

	public OptionPanel() {
		try {


			setLayout(new BorderLayout());
			
			JLabel teamName = new JLabel("직원 정보 검색 시스템");
			tableSelectPanel.add(teamName);
			
			//String[] tableNames = cont.getStringSet(cont.getTables());
			
			//JComboBox tableNameCB = new JComboBox(tableNames);
			//tableNameCB.addActionListener(new myCBListener());
			//tableSelectPanel.add(tableNameCB);
			//super.tableName에 넣기
			
			
			String[] attrNames = cont.getAttrs("EMPLOYEE");
			JLabel startAttr = new JLabel("Select Attributes");
			columnSelectPanel.add(startAttr);
			
			for(int i=0;i<chkBoxName.length;i++) {
				checkBoxes[i] = new JCheckBox(chkBoxName[i], false);
				columnSelectPanel.add(checkBoxes[i]);
				checkBoxes[i].addItemListener(new myItemListener(i));
			}

			JButton selectButton = new JButton("검색하기");
			selectButton.addActionListener(new mySelectListener());
			rightPanel.add(selectButton);

			add(tableSelectPanel,BorderLayout.WEST);
			add(columnSelectPanel,BorderLayout.NORTH);
			add(rightPanel,BorderLayout.EAST);
			add(tablePanel,BorderLayout.CENTER);
		} catch(Exception e) {
			
		}
	}
//	
//	class myCBListener implements ActionListener{
//		@Override
//		public void actionPerformed(ActionEvent e) {
//			JComboBox cb = (JComboBox) e.getSource();
//			tableNumber = cb.getSelectedIndex();
//			//db안의 몇 번째 테이블인지를 반환
//			//System.out.println(tableNumber);
//		}
//		
//	}
//	
	class myItemListener implements ItemListener{
		int num = 0;
		public myItemListener(int i) {
			this.num = i;
		}
		public void itemStateChanged(ItemEvent e) {
			int select = 0;
			if(e.getStateChange() == ItemEvent.SELECTED)
				select = 1;
			else
				select = 0;
			checkValues[num] = select;
		}
	}
	
	class mySelectListener implements ActionListener{
		public mySelectListener() {
			
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			
			System.out.println("checkbox : "+Arrays.toString(checkValues));
			System.out.println("쿼리문을 실행합니다.");
			System.out.println(cont.getResult(cont.selectEmp(checkValues)));
			
			
			//JTable생성(희준)
			str = cont.getResult(cont.selectEmp(checkValues));
			
			Columns = str.split("\n");
			rowSize = Columns.length;

			for(int i=0;i<20;i++) {
				for(int j=0;j<10;j++) {
					Col[i][j]=null;
				}
			}
			
			for(int i = 0;i<9;i++) {
				tableName[i] = null;
			}
			
			String str[] = {};
			int flag = 0;
			int idx = 0;
			for(int i=0;i<checkValues.length;i++) {
				if(checkValues[i] == 1) {
					if(flag == 0) {
						tableName[0] = "선택";
						tableName[1] = chkBoxName[i];
						flag = 1;
						idx = 2;
						num +=2;
						continue;
					}
					tableName[idx] = chkBoxName[i];
					idx++;
					num++;
				}
			}
			
			
			str = Columns[0].split("\\?");
			System.out.println(str.length);

			for(int i = 0;i<Columns.length;i++) {
				ArrayList row = new ArrayList<>();
				str = Columns[i].split("\\?");
				for(int j=0;j<str.length+1;j++) {
					if(j==0) {
						Col[i][j]="";
					}
					else {
						Col[i][j] = str[j-1];
					}	
				}
			}

			//JTable 객체 생성(희준)
			ResultPanel rp = new ResultPanel();
			
			tablePanel.removeAll();
			tablePanel.revalidate();
			tablePanel.add(rp);
			tablePanel.setBounds(1000,1000,1000,1000);
			tablePanel.setVisible(true);			
			
		}
	}
}

class ResultPanel extends Panels {
	//JTable(희준)//
	public ResultPanel() {

		int size =0;
		
		for(int i=0;i<tableName.length;i++) {
			if(tableName[i]!=null) {
				size++;
			}
		}
		
		String init[] = new String[size];
		String rowInfo[][] = new String[rowSize][size];
		//jtable 체크박스
		int jtablechk[] = new int[rowSize];
		
		for(int i=0;i<size;i++) {
			if(tableName[i]!=null) {
				init[i]=tableName[i];
				//System.out.println(init[i]);
			}
		}
		
		for(int i=0;i<rowSize;i++) {
			for(int j=0;j<size;j++) {
				rowInfo[i][j] = Col[i][j];
			}
		}
		
		//체크박스 제외 JTable수정 방지
		DefaultTableModel model = new DefaultTableModel(rowInfo, init) {
			public boolean isCellEditable(int rowIndex, int mColIndex) {
				if(mColIndex == 0) {
					return true;
				}
				else {
					return false;
				}
			}
		};
		
		//체크박스
		DefaultTableCellRenderer dcr = new DefaultTableCellRenderer(){
		 public Component getTableCellRendererComponent  // 셀렌더러
		   (JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
		  {
		   JCheckBox chkbox= new JCheckBox();
		   chkbox.setSelected(((Boolean)value).booleanValue());  
		   chkbox.setHorizontalAlignment(JLabel.CENTER);
		   return chkbox;
		  }
		 };

		 
		if(tableName[0] != null) {
			System.out.println("테이블 업데이트");
			DefaultTableModel dtm = new DefaultTableModel(rowInfo, init);
			JTable table = new JTable(dtm);
			JCheckBox box = new JCheckBox();
			table = new JTable(model);
			
			for(int i = 0;i<size;i++) {
				table.getColumnModel().getColumn(i).setPreferredWidth(100);
			}		
			
			for(int i = 0;i<rowSize;i++) {
				table.setValueAt(false,i,0);
				if(table.getValueAt(i, 0) == (Object)true) {
					jtablechk[i] = 1;
				}
				else {
					jtablechk[i] = 0;
				}
			}
			
			
			
			table.getColumn("선택").setCellRenderer(dcr);
			box.setHorizontalAlignment(JLabel.CENTER);
			table.getColumn("선택").setCellEditor(new DefaultCellEditor(box));
			JScrollPane jsp = new JScrollPane(table);
			jsp.setBounds(new Rectangle(9, 0, 500, 500));
			this.add(jsp);
		}

	}
	
	
	
}